import{W as n}from"./index-BuxSI5VC.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

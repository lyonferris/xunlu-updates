import{W as n}from"./index-CGIb6ZKz.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

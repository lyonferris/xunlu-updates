import{W as n}from"./index-tsAgkP9e.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

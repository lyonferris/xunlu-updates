import{W as n}from"./index-0yKDGcoJ.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

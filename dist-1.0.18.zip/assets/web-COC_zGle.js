import{W as n}from"./index-aEUF4tYs.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

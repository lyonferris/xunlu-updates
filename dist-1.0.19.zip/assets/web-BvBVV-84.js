import{W as n}from"./index-Ba8W0guy.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

import{W as n}from"./index-CdVOM9Y8.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

import{W as n}from"./index-CpJuP-WR.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

import{W as n}from"./index-DGgj3m1j.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

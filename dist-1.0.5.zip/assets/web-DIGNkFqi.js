import{W as n}from"./index-B-0E99ov.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

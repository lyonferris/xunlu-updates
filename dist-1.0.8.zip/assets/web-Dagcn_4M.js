import{W as n}from"./index-Bwclndki.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
